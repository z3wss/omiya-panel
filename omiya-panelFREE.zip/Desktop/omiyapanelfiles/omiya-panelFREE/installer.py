import os
import blessed

term = blessed.Terminal()
underline = term.underline()
bold = term.bold()
reset = term.reset()

rozoviy = term.color_rgb(218, 112, 214)
rozoviyy = term.color_rgb(186, 85, 211)
rozoviyyy = term.color_rgb(147, 112, 219)
rozoviyyyy = term.color_rgb(238, 130, 238)
cyan = term.color_rgb(97, 192, 255)
aquamarine = term.color_rgb(97, 144, 255)
cyann = term.color_rgb(97, 139, 255)
cyannn = term.color_rgb(102, 97, 255)
green = term.color_rgb(0, 255, 127)
white = term.color_rgb(255, 255, 255)

print(f"""
{rozoviy}	╔══╗  ╔═{rozoviyy}╦═╗  ╦{rozoviyyyy} ╦ ╦ ╔══╗{rozoviyyy}    ╔══{cyannn}╗ ╔══╗{aquamarine} ╔╗╔ ╔{cyann}══╗ {cyan}╦
{rozoviy}	║  ║  ║	{rozoviyy}║ ║  ║{rozoviyyyy} ╚╦╝ ║  ║{rozoviyyy}    ╠══{cyannn}╝ ║  ║{aquamarine} ║║║ ╬{cyann}══╝ {cyan}║		
{rozoviy}	║  ║  ║ {rozoviyy}║ ║  ║{rozoviyyyy}  ║  ╠══╣{rozoviyyy}    ║  {cyannn}  ╠══╣{aquamarine} ║║║ ║{cyann}  ╦ {cyan}║  ╦	
{rozoviy}	╚══╝  ╝ {rozoviyy}╩ ╚  ╩{rozoviyyyy}  ╩  ╩  ╩{rozoviyyy}    ╩  {cyannn}  ╩  ╩{aquamarine} ╝╚╝ ╚{cyann}══╝ {cyan}╚══╝

Установщик""")

tocno = input(f"[{cyan}OMIYA~PANEL{white}] Вы действительно хотите установить OMIYA-PANEL(Д/н): ")
tocno = tocno.upper()
if tocno == 'Д' or tocno == 'ДА':
	print('[{cyan}OMIYA~PANEL{white}] Запуск установки...')
	os.system('sudo apt update')
	os.system('sudo apt upgrade -y')
	os.system('sudo apt install python3')
	os.system('sudo apt install php')
	os.system('sudo apt install nodejs')
	os.system('sudo apt install npm')
	os.system('sudo pip3 install requests')
	os.system('sudo pip3 install cfscrape')
	os.system('sudo npm i request --save')
	os.system('sudo npm i cloudscraper --save')
	os.system('sudo npm i https-proxy-agent --save')
	os.system('sudo npm i randomstring --save')
	os.system('sudo npm i ciphers --save')
	print('[{cyan}OMIYA~PANEL{white}] Пакеты были установлены!')
	os.system('sudo chmod +x *')
	openn = input('[{cyan}OMIYA~PANEL{white}] Запустить панель(Д/н): ')
	openn = openn.upper()
	if openn == 'Д' or openn == 'ДА':
		os.system('python3 omiyapanel')
	else: quit
else:
	quit()
